import React from 'react'
import "../css/components/loader.css";

const Loader = () => {
  return (
    <div className="loader"></div> 
  )
}

export default Loader