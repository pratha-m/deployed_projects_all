import React from 'react'

const DetailsForm = () => {
  return (
    <>
         
    </>
  )
}

export default DetailsForm