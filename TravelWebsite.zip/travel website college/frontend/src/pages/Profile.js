import React from 'react'

const Profile = () => {
  return (
    <div className='profilePage'>
         
    </div>
  )
}

export default Profile