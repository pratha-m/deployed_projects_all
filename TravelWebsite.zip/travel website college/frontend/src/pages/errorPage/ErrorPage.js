import React from 'react'

const ErrorPage = () => {
  return (
    <div style={{margin:"100px auto 100px auto"}}>ErrorPage</div>
  )
}

export default ErrorPage